# simple-html-js-calculator (under development)

A JS calculator having basic Addition/Subtraction/Multiplication/Division alongside Square Root/Percent/Pi. 
Apart from these it contains Sin/Cos/Tan/Exponent/Log(logarithm). 
A clear function at the end to clear all your calculations.  
